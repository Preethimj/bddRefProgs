package com.cg.runner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		features={"C:\\Users\\jshamlin\\Desktop\\bdd exam\\MODULE4\\src\\test\\java\\com\\cg\\feature"}
		,glue= {"C:\\Users\\jshamlin\\Desktop\\bdd exam\\MODULE4\\src\\test\\java\\com\\cg\\stpdef\\stepdef.java"}
		//features="com.cg.feature",glue= {"com.cg.stepdef"}
		,plugin = {"pretty", "html:target/shamlin-report"}
		,monochrome=true
		,tags= {"@smoke"}		
//		,dryRun=true
		)
public class r
{    

}

 
